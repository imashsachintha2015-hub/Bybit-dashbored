/**
 * DIV-08 — Risk Governor.
 *
 * In the previous build this agent existed only as a card in the UI reading
 * "Max Loss: 3.0% / Drawdown: 0.0%". There was no code behind it: no daily loss
 * limit, no consecutive-loss breaker, no cap on concurrent positions, no
 * cooldown after a stop-out, and position size was a flat dollar margin per
 * trade regardless of how far away the stop was. A fixed $50 of margin behind a
 * 0.15%-away stop and behind a 1.2%-away stop are two completely different
 * risks wearing the same label.
 *
 * Everything here is enforced before an order can be sent.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MasisRiskGovernor = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {

  const DEFAULTS = {
    // ── Trading Settings ──
    leverage: 10,                    // Bybit leverage (1–100)
    marginMode: 'cross',             // 'cross' or 'isolated'
    sizingMode: 'min',               // 'min' = smallest possible exchange size, 'usdt' = fixed notional, 'risk' = % equity
    fixedUsdtSize: 10,               // USDT margin per trade when sizingMode='usdt'
    targetNotional: 100.0,           // Standard calibrated notional position size ($100 = $10 margin @ 10x)
    maxTradeNotional: 250.0,         // Absolute safety cap on position notional to prevent oversized risk
    riskPerTradePct: 0.5,            // % of equity risked when sizingMode='risk'
    maxConcurrentPositions: 0,       // 0 = uncapped (no maximum concurrent order cap)

    // ── Target & Safety ──
    dailyGrossProfitTarget: 5.0,     // Target gross profit per day in USDT ($5.00/day)
    maxDailyLossPct: 25.0,           // Daily loss limit (% of equity)
    minEquity: 5                     // minimum account balance to trade (adjusted for $10 equity)
  };

  class RiskGovernor {
    constructor(options = {}) {
      this.config = Object.assign({}, DEFAULTS, options);
      this.now = options.now || (() => Date.now());
      this.sessionStartEquity = 0;
      this.currentEquity = 0;
      this.dayKey = this._dayKey();
      this.realisedPnlToday = 0;
      this.dailyGrossProfitToday = 0;
      this.tradesToday = 0;
      this.rMultiples = [];            // realised R per closed trade, for expectancy
      this.symbolCooldowns = new Map(); // symbol -> epoch ms
      this.stopCooldownMs = (options.stopCooldownMs || 15) * 60 * 1000; // 15-min cooldown after a stop-out
    }

    _dayKey(d) {
      const dt = d || new Date(this.now());
      return `${dt.getUTCFullYear()}-${dt.getUTCMonth() + 1}-${dt.getUTCDate()}`;
    }

    _rollDayIfNeeded() {
      const key = this._dayKey();
      if (key !== this.dayKey) {
        this.dayKey = key;
        this.realisedPnlToday = 0;
        this.dailyGrossProfitToday = 0;
        this.tradesToday = 0;
        this.sessionStartEquity = this.currentEquity;
        if (this.pauseReason === 'DAILY_LOSS_LIMIT') {
          this.pausedUntil = 0;
          this.pauseReason = null;
        }
      }
    }

    updateEquity(equity) {
      const e = parseFloat(equity) || 0;
      if (!e) return;
      this.currentEquity = e;
      if (!this.sessionStartEquity) this.sessionStartEquity = e;
      this._rollDayIfNeeded();
    }

    /** Called on every closed trade (including partial scale-outs, with the R
     * attributable to that slice) so the breaker reacts to real outcomes. */
    recordOutcome({ symbol, pnl, rMultiple }) {
      this._rollDayIfNeeded();
      this.realisedPnlToday += pnl;
      if (pnl > 0) {
        this.dailyGrossProfitToday += pnl;
      }
      this.tradesToday++;
      if (typeof rMultiple === 'number' && isFinite(rMultiple)) this.rMultiples.push(rMultiple);
      if (this.rMultiples.length > 200) this.rMultiples.shift();

      // Enforce 15-minute cooldown on stopped-out / loss trades to prevent churn and revenge trading
      if (symbol && (pnl < 0 || (typeof rMultiple === 'number' && rMultiple <= 0))) {
        this.symbolCooldowns.set(symbol, this.now() + this.stopCooldownMs);
      }
    }

    _endOfDayTs() {
      const d = new Date(this.now());
      d.setUTCHours(24, 0, 0, 0);
      return d.getTime();
    }

    /** Expectancy in R — the number that actually says whether the system makes
     * money. Win rate on its own says nothing without average win/loss size. */
    expectancy() {
      if (!this.rMultiples.length) return { sampleSize: 0, expectancyR: 0, winRate: 0, avgWinR: 0, avgLossR: 0 };
      const wins = this.rMultiples.filter(r => r > 0);
      const losses = this.rMultiples.filter(r => r <= 0);
      const avgWin = wins.length ? wins.reduce((a, b) => a + b, 0) / wins.length : 0;
      const avgLoss = losses.length ? Math.abs(losses.reduce((a, b) => a + b, 0) / losses.length) : 0;
      const winRate = this.rMultiples.length ? wins.length / this.rMultiples.length : 0;
      return {
        sampleSize: this.rMultiples.length,
        winRate: +(winRate * 100).toFixed(1),
        avgWinR: +avgWin.toFixed(2),
        avgLossR: +avgLoss.toFixed(2),
        expectancyR: +(winRate * avgWin - (1 - winRate) * avgLoss).toFixed(3)
      };
    }

    /**
     * The gate. Returns { allowed, reasons[] } — every refusal names itself so
     * the operator can see exactly why the system stood down.
     */
    canOpen({ symbol, openPositions = [], pendingOrders = [] }) {
      this._rollDayIfNeeded();
      const reasons = [];

      // 0. Daily gross profit target lock ($5.00/day)
      if (this.config.dailyGrossProfitTarget > 0 && this.dailyGrossProfitToday >= this.config.dailyGrossProfitTarget) {
        reasons.push(`Daily gross profit target ($${this.config.dailyGrossProfitTarget.toFixed(2)}) reached ($${this.dailyGrossProfitToday.toFixed(2)}) — trading completed for the day`);
      }

      // 1. Minimum equity
      if (this.currentEquity > 0 && this.currentEquity < this.config.minEquity) {
        reasons.push(`Equity ${this.currentEquity.toFixed(2)} is below the ${this.config.minEquity} minimum`);
      }

      // 2. Daily loss limit
      const base = this.sessionStartEquity || this.currentEquity;
      if (base > 0 && this.realisedPnlToday < 0) {
        const lossPct = Math.abs(this.realisedPnlToday) / base * 100;
        if (lossPct >= this.config.maxDailyLossPct) {
          reasons.push(`Daily loss limit reached (${lossPct.toFixed(2)}% of starting equity)`);
        }
      }

      // 3. Same-coin duplicate guard (live positions OR resting limit orders)
      if (openPositions.some(p => p.symbol === symbol)) {
        reasons.push(`Already holding a live ${symbol} position`);
      }
      if (pendingOrders.some(o => o.symbol === symbol)) {
        reasons.push(`A limit order for ${symbol} is already resting`);
      }

      // 4. Maximum concurrent positions (if set > 0; 0 means uncapped)
      if (this.config.maxConcurrentPositions && this.config.maxConcurrentPositions > 0 && openPositions.length >= this.config.maxConcurrentPositions) {
        reasons.push(`Maximum concurrent positions reached (${openPositions.length}/${this.config.maxConcurrentPositions})`);
      }

      // 5. Mandatory Per-Symbol Cooldown following a stop-out (15 min)
      const cdUntil = this.symbolCooldowns.get(symbol) || 0;
      if (this.now() < cdUntil) {
        const remainMin = Math.ceil((cdUntil - this.now()) / 60000);
        reasons.push(`${symbol} is in cooldown for another ${remainMin}m after a recent stop-out to prevent churn`);
      }

      return { allowed: reasons.length === 0, reasons };
    }

    isCoolingDown(symbol) {
      return this.now() < (this.symbolCooldowns.get(symbol) || 0);
    }

    getRemainingCooldownMin(symbol) {
      const cdUntil = this.symbolCooldowns.get(symbol) || 0;
      return Math.max(0, Math.ceil((cdUntil - this.now()) / 60000));
    }

    /**
     * Two sizing modes:
     *
     *   'risk' (default) — size by risk, not by margin. Quantity is set so
     *   that entry-to-stop equals exactly `riskPerTradePct` of equity — a
     *   wide stop gets a small position, a tight stop gets a larger one,
     *   and every trade loses the same amount when it is wrong. That single
     *   change is what makes a win rate meaningful.
     *
     *   'usdt' — size to a fixed notional (`fixedUsdtSize`) instead,
     *   regardless of stop distance. Simpler to reason about in dollar
     *   terms, at the cost of the property above: a trade with a stop twice
     *   as far away now risks twice as much of that fixed notional as one
     *   with a tight stop. An explicit operator choice, not the default.
     */
    sizePosition({ entry, stop, equity, symbol, qtyStep, minQty, maxLeverage = 10 }) {
      const eq = equity || this.currentEquity;
      const riskDist = Math.abs(entry - stop);
      if (!eq || !riskDist || !entry) {
        return { qty: 0, rejected: 'Missing equity, entry or stop' };
      }

      const step = qtyStep || 0.001;
      const minQ = minQty || step;
      const minNotional = 5.0; // Bybit linear contract minimum order notional is 5 USDT

      // 1. MIN SIZING MODE: Absolute smallest valid legal order for this coin on Bybit
      if (this.config.sizingMode === 'min') {
        let q = Math.max(minQ, Math.ceil(minNotional / entry / step) * step);
        q = Math.floor(q / step) * step;
        q = +q.toFixed(8);
        return {
          qty: q,
          riskAmount: +(riskDist * q).toFixed(2),
          notional: +(q * entry).toFixed(2),
          effectiveLeverage: +((q * entry) / eq).toFixed(2)
        };
      }

      // 2. VOL_ADJUSTED MODE: normalises the dollar risk per trade across all coins.
      // Size = riskBudget / (atrPct × leverage × entry). A coin with 8× the ATR
      // of BTC gets an 8× smaller position, so each trade risks the same dollars.
      if (this.config.sizingMode === 'vol_adjusted') {
        const atrPct = this.config.atrPct || 0.01; // caller must supply current ATR%
        const lev = this.config.leverage || 10;
        const riskBudget = eq * (this.config.riskPerTradePct / 100);
        // Dollar risk = position_notional * atrPct, so position_notional = riskBudget / atrPct
        let notional = riskBudget / Math.max(atrPct, 0.001);
        // Cap at leverage ceiling
        const maxNotional = eq * lev;
        if (notional > maxNotional) notional = maxNotional;
        let q = notional / entry;
        q = Math.floor(q / step) * step;
        if (q * entry < minNotional) q = Math.ceil(minNotional / entry / step) * step;
        if (q < minQ) q = minQ;
        q = +q.toFixed(8);
        return {
          qty: q,
          riskAmount: +(riskDist * q).toFixed(2),
          notional: +(q * entry).toFixed(2),
          effectiveLeverage: +((q * entry) / eq).toFixed(2),
          sizingNote: `Vol-adjusted: ATR% ${(atrPct * 100).toFixed(2)}%, risk budget $${riskBudget.toFixed(2)}`
        };
      }

      const usdtMode = this.config.sizingMode === 'usdt';
      let targetNotional = this.config.targetNotional || 100.0;
      if (usdtMode && this.config.fixedUsdtSize > 0) {
        targetNotional = (this.config.fixedUsdtSize <= 25)
          ? this.config.fixedUsdtSize * (this.config.leverage || 10)
          : this.config.fixedUsdtSize;
      }
      const riskAmount = usdtMode ? +(riskDist * (targetNotional / entry)).toFixed(2) : eq * (this.config.riskPerTradePct / 100);
      let qty = usdtMode ? targetNotional / entry : riskAmount / riskDist;

      // Never let sizing push notional past the leverage ceiling or max trade notional safety cap
      const effLev = Math.max(1, this.config.leverage || maxLeverage);
      const maxNotional = Math.min(eq * effLev, this.config.maxTradeNotional || 250.0);
      if (qty * entry > maxNotional) {
        qty = maxNotional / entry;
      }

      qty = Math.floor(qty / step) * step;
      qty = +qty.toFixed(8);

      // Ensure minimum 5 USDT notional on Bybit linear contracts
      if (qty * entry < minNotional) {
        qty = Math.ceil(minNotional / entry / step) * step;
        qty = +qty.toFixed(8);
      }

      if (minQty && qty < minQty) {
        // If the user configured a small USDT size, clamp to minQty rather than rejecting
        if (usdtMode && this.config.fixedUsdtSize <= 50) {
          qty = minQty;
        } else {
          return {
            qty: 0,
            rejected: usdtMode
              ? `Size at $${this.config.fixedUsdtSize} notional (${qty}) is below ${symbol}'s minimum order size (${minQty}). Raise the USDT size to trade this symbol.`
              : `Risk-based size (${qty}) is below ${symbol}'s minimum order size (${minQty}). Raising size would mean risking more than ${this.config.riskPerTradePct}% of equity on this trade, so the trade is skipped instead.`
          };
        }
      }
      if (qty <= 0) {
        return { qty: 0, rejected: `${usdtMode ? 'Fixed-USDT' : 'Risk-based'} size rounds to zero at ${symbol}'s step size` };
      }

      return {
        qty,
        riskAmount,
        notional: +(qty * entry).toFixed(2),
        effectiveLeverage: +((qty * entry) / eq).toFixed(2)
      };
    }

    status() {
      const base = this.sessionStartEquity || this.currentEquity;
      return {
        leverage: this.config.leverage,
        marginMode: this.config.marginMode,
        sizingMode: this.config.sizingMode,
        fixedUsdtSize: this.config.fixedUsdtSize,
        riskPerTradePct: this.config.riskPerTradePct,
        realisedPnlToday: +this.realisedPnlToday.toFixed(2),
        dailyLossPct: base > 0 ? +((Math.abs(Math.min(this.realisedPnlToday, 0)) / base) * 100).toFixed(2) : 0,
        maxDailyLossPct: this.config.maxDailyLossPct,
        tradesToday: this.tradesToday,
        expectancy: this.expectancy(),
        activeCooldowns: Array.from(this.symbolCooldowns.entries())
          .filter(([, cd]) => this.now() < cd)
          .map(([sym, cd]) => ({ symbol: sym, remainingMin: Math.ceil((cd - this.now()) / 60000) }))
      };
    }
  }

  return { RiskGovernor, DEFAULTS };
});
