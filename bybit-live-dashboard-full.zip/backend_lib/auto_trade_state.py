"""Cross-device autonomous-execution arm state.

The dashboard has no login/session system -- it's a single shared demo
account, and the entire decision engine (regime read, setup grading, the
analyst panel, position management) runs client-side in whichever browser
tab has the page open. Before this, whether auto-trading was ARMED or
STOPPED lived only in that one tab's JS memory (a plain `let`), so opening
the dashboard on a different device, or even just reloading, always came
back up STOPPED regardless of what was armed a moment ago elsewhere.

This persists the arm flag and the position-sizing configuration (risk % of
equity, or a fixed USDT notional per trade -- see agents/risk-governor.js's
two sizing modes) through kv.py, so every device shows the same, current
state. It does NOT make it safe to have two tabs both actively armed at
once: each tab's engine runs and places orders independently, with no
shared lock between them, so two tabs seeing the same signal in the same
cycle can both fire an order. Treat this as "which device is currently
driving trades, sized how" staying visible and consistent across devices,
not as multi-device coordination.
"""
from .kv import kv_get_json, kv_set_json

STATE_KEY = "auto_trade_state"

DEFAULT_STATE = {
    "armed": False,
    "virtualEquity": 10.0,
    "riskPerTradePct": 5.0,
    "sizingMode": "usdt",
    "fixedUsdtSize": 10,
    "targetNotional": 100.0,
    "dailyGrossTarget": 5.0,
    "maxConcurrentPositions": 1,
    "leverage": 10,
    "marginMode": "cross",
    "theses": {},
}


def load():
    state = kv_get_json(STATE_KEY, None)
    if not state:
        return dict(DEFAULT_STATE)
    return {**DEFAULT_STATE, **state}


def save(armed=None, risk_per_trade_pct=None, sizing_mode=None, fixed_usdt_size=None, leverage=None, margin_mode=None, theses=None, daily_gross_target=None, target_notional=None, virtual_equity=None, max_concurrent_positions=None):
    current = load()
    merged_theses = dict(current.get("theses", {}) or {})
    if isinstance(theses, dict):
        for k, v in theses.items():
            if v is None:
                merged_theses.pop(k, None)
            else:
                merged_theses[k] = v

    state = {
        "armed": bool(armed) if armed is not None else current.get("armed", False),
        "virtualEquity": float(virtual_equity) if virtual_equity is not None else current.get("virtualEquity", 10.0),
        "riskPerTradePct": float(risk_per_trade_pct) if risk_per_trade_pct is not None else current.get("riskPerTradePct", 5.0),
        "sizingMode": sizing_mode if sizing_mode in ("risk", "usdt", "min") else current.get("sizingMode", "usdt"),
        "fixedUsdtSize": float(fixed_usdt_size) if fixed_usdt_size is not None else current.get("fixedUsdtSize", 10),
        "targetNotional": float(target_notional) if target_notional is not None else current.get("targetNotional", 100.0),
        "dailyGrossTarget": float(daily_gross_target) if daily_gross_target is not None else current.get("dailyGrossTarget", 5.0),
        "maxConcurrentPositions": int(max_concurrent_positions) if max_concurrent_positions is not None else current.get("maxConcurrentPositions", 1),
        "leverage": int(leverage) if leverage and int(leverage) > 0 else current.get("leverage", 10),
        "marginMode": str(margin_mode).lower() if str(margin_mode).lower() in ("cross", "isolated") else current.get("marginMode", "cross"),
        "theses": merged_theses,
    }
    kv_set_json(STATE_KEY, state)
    return state
